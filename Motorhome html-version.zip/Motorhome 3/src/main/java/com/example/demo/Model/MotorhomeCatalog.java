package com.example.demo.Model;

public class MotorhomeCatalog {

    private String manufacturer;
    private String model;
    private int year;
    private double price;
}
