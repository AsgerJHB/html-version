package com.example.demo.Reps;

import com.example.demo.Model.RentalModel;

public interface IRentalRep  {

    public boolean createRental(RentalModel rentalModel);
}
